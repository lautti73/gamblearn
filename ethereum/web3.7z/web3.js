import Web3 from "web3";
import detectEthereumProvider from '@metamask/detect-provider';
 
let web3;
let chainId;

 
if (typeof window !== "undefined" && typeof window.ethereum !== "undefined") {
  // We are in the browser and metamask is running.
  

// this returns the provider, or null if it wasn't detected
  const provider = await detectEthereumProvider();

  if (provider) {
    startApp(provider); // Initialize your app
  } else {
    console.log('Please install MetaMask!');
  }

  function startApp(provider) {
    // If the provider returned by detectEthereumProvider is not the same as
    // window.ethereum, something is overwriting it, perhaps another wallet.
    if (provider !== window.ethereum) {
      console.error('Do you have multiple wallets installed?');
      web3 = new Web3(provider)
    }
    // Access the decentralized web!
  }

  chainId = await ethereum.request({ method: 'eth_chainId' });
 // handleChainChanged(chainId);

  ethereum.on('chainChanged', handleChainChanged);

  function handleChainChanged(_chainId) {
    // We recommend reloading the page, unless you must do otherwise
    window.location.reload();

  } 

  let currentAccount = null;

  await ethereum.request({ method: 'eth_accounts' })

// Note that this event is emitted on page load.
// If the array of accounts is non-empty, you're already
// connected.
  ethereum.on('accountsChanged', handleAccountsChanged);

// For now, 'eth_accounts' will continue to always return an array
  function handleAccountsChanged(accounts) {
    if (accounts.length === 0) {
    // MetaMask is locked or the user has not connected any accounts
      console.log('Please connect to MetaMask.');
    } else if (accounts[0] !== currentAccount) {
      currentAccount = accounts[0];
    // Do any other work!
    }
  }

  console.log('se ejecuta el web3 en el cliente')




} else {
  // We are on the server *OR* the user is not running metamask
  const provider = new Web3.providers.HttpProvider(
    'https://rinkeby.infura.io/v3/971744bb115946f59bb8767d2d6bea02'
  );
  web3 = new Web3(provider);
}


 
export default web3;

